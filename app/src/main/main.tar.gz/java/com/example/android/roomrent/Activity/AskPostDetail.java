package com.example.android.roomrent.Activity;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.android.roomrent.Model.PostDatum;

/**
 * Created by mka on 5/11/17.
 */

public class AskPostDetail extends AppCompatActivity {

    TextView askPostDetail;
    PostDatum postDatum;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_post_detail);

        askPostDetail = (TextView) findViewById(R.id.askPostDetail);
        // initialize User Data
        Bundle data = getIntent().getExtras();
        postDatum = data.getParcelable("askPost");

        askPostDetail.setText(postDatum.toString());
    }
}
