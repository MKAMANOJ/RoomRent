package com.example.android.roomrent.Helper;

/**
 * Created by mka on 5/5/17.
 */

public interface PaginationAdapterCallback {



    void retryPageLoad();
}
