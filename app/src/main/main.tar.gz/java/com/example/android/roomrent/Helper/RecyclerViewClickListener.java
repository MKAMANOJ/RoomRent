package com.example.android.roomrent.Helper;

import android.view.View;

/**
 * Created by mka on 5/11/17.
 */

public interface RecyclerViewClickListener {

    public void recyclerViewListClicked(View v, int position);
}
